; ============================================================
;   MiniOyinlar — Windows installer (Inno Setup skripti)
; ============================================================
;   Bu fayl build_windows.bat tomonidan avtomatik chaqiriladi.
;   Qo'lda yasash uchun: Inno Setup'ni o'rnatib, shu faylni oching va
;   "Build > Compile" bosing (yoki: ISCC.exe installer.iss).
;
;   Talab: avval PyInstaller bilan dist\MiniOyinlar\ papkasi yasalgan bo'lsin.
; ============================================================

#define AppName "MiniOyinlar"
#define AppVersion "1.0.0"
#define AppPublisher "MiniOyinlar"
#define AppExe "MiniOyinlar.exe"

[Setup]
; AppId — dasturning yagona identifikatori (yangilash/o'chirish uchun o'zgarmasin)
AppId={{A7F3C2E1-9B4D-4E6A-8C1F-2D5E7A9B3C4F}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
; Admin shart emas — har bir foydalanuvchi uchun o'rnatiladi
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=installer_output
OutputBaseFilename=MiniOyinlar-Setup
SetupIconFile=assets\icon.ico
UninstallDisplayIcon={app}\{#AppExe}
UninstallDisplayName={#AppName}
WizardStyle=modern
Compression=lzma2/max
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "uz"; MessagesFile: "compiler:Default.isl"
Name: "ru"; MessagesFile: "compiler:Languages\Russian.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
; PyInstaller --onedir natijasi: butun papkani ko'chiramiz
Source: "dist\MiniOyinlar\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{group}\{cm:UninstallProgram,{#AppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "{cm:LaunchProgram,{#AppName}}"; Flags: nowait postinstall skipifsilent
