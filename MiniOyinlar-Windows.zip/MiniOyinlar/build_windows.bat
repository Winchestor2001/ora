@echo off
chcp 65001 >nul
cd /d "%~dp0"
REM ============================================================
REM   MiniOyinlar — Windows uchun INSTALLER yasash skripti
REM ============================================================
REM   Natija:  installer_output\MiniOyinlar-Setup.exe
REM            (foydalanuvchi shuni o'rnatadi — Python kerak emas)
REM
REM   Talablar (faqat shu kompyuterda, bir marta):
REM     1) python.org dan Python 3.10+  ("Add Python to PATH" belgilang!)
REM     2) Inno Setup 6:  https://jrsoftware.org/isdl.php
REM     3) Internet (kutubxonalar yuklab olinadi)
REM
REM   Ishlatish: shu faylni ikki marta bosing.
REM ============================================================

echo.
echo === [1/3] Kerakli kutubxonalar o'rnatilmoqda... ===
python -m pip install --upgrade pip
python -m pip install pygame numpy pyinstaller
if errorlevel 1 (
    echo.
    echo XATO: kutubxonalar o'rnatilmadi. Python to'g'ri o'rnatilganini tekshiring.
    echo "python --version" buyrug'i ishlashi kerak.
    pause
    exit /b 1
)

echo.
echo === [2/3] MiniOyinlar.exe yasalmoqda (1-2 daqiqa)... ===
REM Eski natijalarni tozalaymiz (xato bo'lmasligi uchun)
if exist "dist\MiniOyinlar" rmdir /s /q "dist\MiniOyinlar"
python -m PyInstaller --noconfirm --onedir --windowed ^
  --name "MiniOyinlar" ^
  --icon "assets\icon.ico" ^
  --hidden-import platformer ^
  --hidden-import space_game ^
  launcher.py
if errorlevel 1 (
    echo.
    echo XATO: .exe yasalmadi. Yuqoridagi xabarlarni tekshiring.
    pause
    exit /b 1
)

echo.
echo === [3/3] Installer (MiniOyinlar-Setup.exe) yasalmoqda... ===
REM Inno Setup kompilyatorini (ISCC.exe) topamiz
set "ISCC="
where iscc >nul 2>&1 && set "ISCC=iscc"
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if not defined ISCC (
    echo.
    echo OGOHLANTIRISH: Inno Setup topilmadi — installer yasalmadi.
    echo   Lekin dist\MiniOyinlar\MiniOyinlar.exe tayyor (papka bilan ishlaydi).
    echo.
    echo   Installer ham kerak bo'lsa:
    echo     1) https://jrsoftware.org/isdl.php dan Inno Setup 6 ni o'rnating
    echo     2) Shu .bat faylni qayta ishga tushiring
    echo   yoki installer.iss faylini Inno Setup'da ochib "Compile" bosing.
    pause
    exit /b 1
)

"%ISCC%" installer.iss
if errorlevel 1 (
    echo.
    echo XATO: installer yasalmadi. Yuqoridagi xabarlarni tekshiring.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   TAYYOR!  Natija:  installer_output\MiniOyinlar-Setup.exe
echo   Shu faylni boshqalarga bering — ular o'rnatib o'ynaydi.
echo   (O'rnatgach: Ish stoli / Start menyuda "MiniOyinlar" yorlig'i)
echo ============================================================
pause
