# 🎮 MiniOyinlar

Bitta dasturda **2 ta o'yin**:

1. **KOSMIK JANG** — kosmik kemada dushmanlarni otib tushiring
2. **AG'DAR** — gravitatsiyani ag'darib o'ynaydigan platformer

Dastur ishga tushganda **o'yinlar ro'yxati** chiqadi. Birini tanlaysiz va
o'ynaysiz. Istalgan paytda o'yindan chiqsangiz (o'yin menyusida **ESC**), yana
shu ro'yxatga qaytasiz va boshqa o'yin tanlay olasiz.

**Til:** menyu **o'zbekcha (UZ)** va **ruscha (RU)** — yuqori o'ng burchakdagi
`UZ / RU` tugmasini bosing yoki `L` tugmasini bosing. Tanlagan tilingiz eslab
qolinadi.

---

## ▶️ Ishga tushirish

### Mac'da — Python orqali (eng oson)
Terminal'da shu papkada:
```bash
.venv/bin/python launcher.py
```
yoki tizim Python'i bilan:
```bash
python3 launcher.py
```

### Mac'da — .app orqali (Python kerak emas)
`dist/MiniOyinlar.app` faylini Finder'da **ikki marta bosing**.

> Birinchi ochishda macOS "noma'lum dasturchi" deb ogohlantirsa:
> `.app` ustida **o'ng tugma → Open → Open** qiling (faqat bir marta kerak).

---

## 🪟 Windows uchun installer yasash

Installer (`MiniOyinlar-Setup.exe`) faqat **Windows kompyuterda** yasaladi
(Mac'da Windows uchun yasab bo'lmaydi). Tartib:

1. Bu butun papkani Windows kompyuterga ko'chiring (`assets\icon.ico`,
   `installer.iss`, `launcher.py`, `platformer.py`, `space_game.py`,
   `build_windows.bat` — hammasi birga bo'lsin).
2. [python.org](https://www.python.org/downloads/) dan **Python 3.10+** o'rnating.
   O'rnatishda **"Add Python to PATH"** katagiga belgi qo'ying!
3. [jrsoftware.org/isdl.php](https://jrsoftware.org/isdl.php) dan **Inno Setup 6**
   ni o'rnating (installer yasovchi, bepul).
4. `build_windows.bat` faylini **ikki marta bosing**. U o'zi:
   `.exe` yasaydi (icon bilan) → installer'ga to'playdi.
5. Natija: **`installer_output\MiniOyinlar-Setup.exe`**.

> **Tarqatish:** faqat shu `MiniOyinlar-Setup.exe` faylni bering. Foydalanuvchi
> uni o'rnatadi (Python kerak emas), Ish stoli va Start menyusida **MiniOyinlar**
> yorlig'i (icon bilan) paydo bo'ladi. O'chirish ham oddiy — "Programs"dan.

> Inno Setup o'rnatilmagan bo'lsa ham `.bat` ishlaydi: u hech bo'lmasa
> `dist\MiniOyinlar\` papkasidagi `MiniOyinlar.exe` ni yasaydi (papka bilan
> ko'chirib ishlatsa bo'ladi), faqat yagona installer fayli bo'lmaydi.

### Iconni o'zgartirish
Icon `assets\icon.ico`. Dizaynni o'zgartirmoqchi bo'lsangiz `assets/make_icon.py`
ni tahrirlab qayta yarating (Pillow kerak: `pip install Pillow`):
```bash
python assets/make_icon.py
```

---

## ⌨️ Boshqaruv

**Ro'yxat (bosh menyu):**
| Tugma | Vazifa |
|-------|--------|
| ↑ / ↓ | o'yin tanlash |
| ENTER / SPACE | o'ynash |
| 1, 2 | raqam bilan tez tanlash |
| L | til (UZ ⇄ RU) |
| Sichqoncha | ustiga olib borib bosish |
| ESC | chiqish |

**O'yin ichida:** har bir o'yinning o'z boshqaruvi bor (o'yin ichida ko'rsatilgan).
Umumiy: **ESC** — orqaga / menyuga, **M** — o'yin menyusi, **F** — to'liq ekran, **P** — pauza.
Bosh ro'yxatga qaytish uchun o'yin menyusida **ESC** bosing.

---

## ➕ Yangi o'yin qo'shish

`launcher.py` ichidagi `GAMES` ro'yxatiga bitta element qo'shing:
```python
GAMES = [
    {"title": "...", "subtitle": "...", "run": mening_oyinim.main,
     "accent": (90, 200, 255), "icon": "ship"},
    ...
]
```
va yuqorida `import mening_oyinim` qiling. Boshqa hech narsa kerak emas —
ro'yxat avtomatik yangilanadi.

---

## 📁 Fayllar

| Fayl | Nima |
|------|------|
| `launcher.py` | bosh menyu (asosiy dastur) |
| `space_game.py` | Kosmik Jang o'yini |
| `platformer.py` | Ag'dar o'yini |
| `build_windows.bat` | Windows installer yasash skripti |
| `installer.iss` | Inno Setup installer ta'rifi |
| `assets/icon.ico` | ilova ikonkasi (Windows) |
| `assets/make_icon.py` | iconni qayta yasash skripti |
| `build_mac.sh` | Mac `.app` yasash skripti |
| `requirements.txt` | kerakli kutubxonalar |
| `dist/MiniOyinlar.app` | tayyor Mac dasturi |

> Rekord (highscore) fayllari: oddiy Python'da shu papkada, `.app`/`.exe`'da esa
> uy papkangizdagi `~/.mini_oyinlar/` (Windows'da `C:\Users\<siz>\.mini_oyinlar\`) ichida saqlanadi.
