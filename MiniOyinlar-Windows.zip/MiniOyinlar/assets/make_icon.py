# -*- coding: utf-8 -*-
"""
MiniOyinlar — icon generator
============================
Windows (.ico), Mac (.icns uchun .png) va umumiy preview uchun ilova ikonkasini
yasaydi. Dizayn o'yinlar uslubiga mos: to'q kosmik gradient fon + yulduzlar +
raketa (KOSMIK JANG — cyan) va orange aksent (AG'DAR).

Ishga tushirish:
    python assets/make_icon.py

Natija:
    assets/icon.ico   — Windows (16,32,48,64,128,256 px)
    assets/icon.png   — 1024px preview (Mac/umumiy uchun)
"""

import os
import math

from PIL import Image, ImageDraw, ImageFilter

# Supersampling: katta o'lchamda chizib, keyin kichraytiramiz (silliq qirralar)
SS = 2048
OUT_DIR = os.path.dirname(os.path.abspath(__file__))

# O'yin ranglari (launcher.py bilan bir xil)
CYAN = (90, 200, 255)
ORANGE = (255, 170, 70)
BG_TOP = (10, 12, 40)
BG_BOTTOM = (32, 10, 52)
WHITE = (240, 244, 255)


def _lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _vertical_gradient(size, top, bottom):
    """Yuqoridan pastga vertikal gradient (RGBA)."""
    grad = Image.new("RGB", (1, size), 0)
    for y in range(size):
        grad.putpixel((0, y), _lerp(top, bottom, y / max(1, size - 1)))
    return grad.resize((size, size)).convert("RGBA")


def _radial_glow(size, center, radius, color, max_alpha):
    """Yumshoq doiraviy yorug'lik (raketa olovi / orqa fon nuri uchun)."""
    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(glow)
    cx, cy = center
    steps = 60
    for i in range(steps, 0, -1):
        t = i / steps
        r = radius * t
        a = int(max_alpha * (1 - t) ** 2)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color + (a,))
    return glow


def _draw_stars(img):
    """Fon yulduzlari — turli o'lchamdagi nuqtalar."""
    d = ImageDraw.Draw(img)
    S = img.size[0]
    # (x_nisbiy, y_nisbiy, radius_nisbiy, yorqinlik)
    stars = [
        (0.18, 0.20, 0.012, 200), (0.30, 0.12, 0.007, 150),
        (0.78, 0.18, 0.014, 220), (0.86, 0.30, 0.008, 160),
        (0.14, 0.46, 0.009, 170), (0.84, 0.62, 0.010, 180),
        (0.24, 0.74, 0.007, 140), (0.72, 0.82, 0.012, 200),
        (0.50, 0.10, 0.006, 130), (0.62, 0.26, 0.008, 150),
    ]
    for sx, sy, sr, a in stars:
        x, y, r = sx * S, sy * S, sr * S
        d.ellipse([x - r, y - r, x + r, y + r], fill=WHITE + (a,))
    # Bir nechta 4-nurli "yulduzcha"
    for sx, sy, ln in [(0.74, 0.16, 0.05), (0.20, 0.42, 0.035)]:
        x, y, L = sx * S, sy * S, ln * S
        w = max(2, int(L * 0.12))
        d.line([x - L, y, x + L, y], fill=WHITE + (210,), width=w)
        d.line([x, y - L, x, y + L], fill=WHITE + (210,), width=w)


def _draw_rocket(base):
    """Markazda raketa: cyan tana, orange qanot, orange-sariq olov."""
    S = base.size[0]
    cx = S * 0.5
    cy = S * 0.50

    # --- Olov yorug'ligi (tana ortidan) ---
    glow = _radial_glow(S, (cx, cy + S * 0.30), S * 0.22, ORANGE, 120)
    base.alpha_composite(glow)

    rocket = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(rocket)

    body_w = S * 0.20
    body_top = cy - S * 0.16
    body_bot = cy + S * 0.18

    # --- Qanotlar (orange) ---
    fin = S * 0.11
    d.polygon([
        (cx - body_w / 2, body_bot - S * 0.10),
        (cx - body_w / 2 - fin, body_bot + S * 0.04),
        (cx - body_w / 2, body_bot),
    ], fill=ORANGE + (255,))
    d.polygon([
        (cx + body_w / 2, body_bot - S * 0.10),
        (cx + body_w / 2 + fin, body_bot + S * 0.04),
        (cx + body_w / 2, body_bot),
    ], fill=ORANGE + (255,))

    # --- Tana (oq-cyan kapsula) ---
    d.rounded_rectangle(
        [cx - body_w / 2, body_top, cx + body_w / 2, body_bot],
        radius=body_w * 0.5, fill=WHITE + (255,),
    )
    # Chap tomonda yengil cyan soya (hajm hissi)
    d.rounded_rectangle(
        [cx - body_w / 2, body_top, cx - body_w * 0.12, body_bot],
        radius=body_w * 0.3, fill=_lerp(WHITE, CYAN, 0.30) + (255,),
    )

    # --- Burun konusi (cyan) ---
    d.polygon([
        (cx, cy - S * 0.30),
        (cx - body_w / 2, body_top + S * 0.02),
        (cx + body_w / 2, body_top + S * 0.02),
    ], fill=CYAN + (255,))

    # --- Oyna (to'q cyan halqa + yorqin markaz) ---
    wr = body_w * 0.30
    wy = cy - S * 0.04
    d.ellipse([cx - wr, wy - wr, cx + wr, wy + wr], fill=_lerp(CYAN, BG_TOP, 0.35) + (255,))
    d.ellipse([cx - wr * 0.6, wy - wr * 0.6, cx + wr * 0.6, wy + wr * 0.6],
              fill=_lerp(CYAN, WHITE, 0.5) + (255,))

    # --- Olov (orange→sariq) ---
    flame_top = body_bot - S * 0.01
    d.polygon([
        (cx - body_w * 0.34, flame_top),
        (cx + body_w * 0.34, flame_top),
        (cx, flame_top + S * 0.17),
    ], fill=ORANGE + (255,))
    d.polygon([
        (cx - body_w * 0.18, flame_top),
        (cx + body_w * 0.18, flame_top),
        (cx, flame_top + S * 0.10),
    ], fill=(255, 230, 120, 255))

    base.alpha_composite(rocket)


def build():
    # 1) Fon gradienti + orqa nur
    img = _vertical_gradient(SS, BG_TOP, BG_BOTTOM)
    img.alpha_composite(_radial_glow(SS, (SS * 0.5, SS * 0.42), SS * 0.5, CYAN, 45))

    # 2) Yulduzlar
    _draw_stars(img)

    # 3) Raketa
    _draw_rocket(img)

    # 4) Orange platforma chizig'i (AG'DAR aksenti) — pastda
    d = ImageDraw.Draw(img)
    py = SS * 0.86
    d.rounded_rectangle([SS * 0.30, py, SS * 0.70, py + SS * 0.022],
                        radius=SS * 0.011, fill=ORANGE + (235,))

    # 5) Yumaloq burchakli ilova ikonkasi maskasi
    mask = Image.new("L", (SS, SS), 0)
    md = ImageDraw.Draw(mask)
    md.rounded_rectangle([0, 0, SS - 1, SS - 1], radius=int(SS * 0.225), fill=255)
    img.putalpha(mask)

    # 6) Nozik ichki yorug'lik chegarasi (premium ko'rinish)
    border = Image.new("RGBA", (SS, SS), (0, 0, 0, 0))
    bd = ImageDraw.Draw(border)
    bd.rounded_rectangle([SS * 0.012, SS * 0.012, SS * 0.988, SS * 0.988],
                         radius=int(SS * 0.213), outline=WHITE + (40,),
                         width=int(SS * 0.006))
    img.alpha_composite(border)

    # --- Saqlash ---
    png_path = os.path.join(OUT_DIR, "icon.png")
    img.resize((1024, 1024), Image.LANCZOS).save(png_path)

    ico_path = os.path.join(OUT_DIR, "icon.ico")
    sizes = [16, 32, 48, 64, 128, 256]
    frames = [img.resize((s, s), Image.LANCZOS) for s in sizes]
    frames[-1].save(ico_path, format="ICO",
                    sizes=[(s, s) for s in sizes], append_images=frames[:-1])

    print("Tayyor:")
    print("  " + png_path)
    print("  " + ico_path)


if __name__ == "__main__":
    build()
