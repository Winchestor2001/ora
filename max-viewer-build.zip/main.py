"""Точка входа CLI — тонкий клиент к серверу MAX Channel Viewer.

Вся логика (браузерные просмотры, планировщик, БД, токены) выполняется на
сервере. CLI лишь отправляет команды по HTTP. Без аргументов открывается
интерактивная оболочка; те же действия доступны как подкоманды.
"""
import argparse
import asyncio
import sys

DEFAULT_DWELL = 20


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="max-viewer",
        description=(
            "MAX Channel Viewer — пульт управления сервером.\n"
            "Без аргументов открывается интерактивная оболочка."
        ),
    )
    sub = parser.add_subparsers(dest="command", metavar="<команда>")

    cfg = sub.add_parser("configure", help="Настроить адрес сервера, логин и пароль")
    cfg.add_argument("--url", default=None, help="URL сервера (http://127.0.0.1:8000)")
    cfg.add_argument("--user", default=None, help="Логин")
    cfg.add_argument("--password", default=None, help="Пароль")

    sub.add_parser("add-account", help="Добавить аккаунт через QR (с сервера)")
    sub.add_parser("add-account-manual", help="Добавить аккаунт вручную (paste из DevTools)")
    sub.add_parser("list-accounts", help="Список аккаунтов")
    rm = sub.add_parser("remove-account", help="Удалить аккаунт")
    rm.add_argument("id", type=int, help="ID аккаунта")

    ach = sub.add_parser("add-channel", help="Добавить канал (url/chat_id/invite)")
    ach.add_argument("target", type=str, help="URL, chat_id или invite-ссылка")
    sub.add_parser("list-channels", help="Список каналов")
    rch = sub.add_parser("remove-channel", help="Удалить канал")
    rch.add_argument("id", type=int, help="ID канала")
    rfm = sub.add_parser("refresh-memberships", help="Обновить статус членства аккаунтов в канале")
    rfm.add_argument("id", type=int, help="ID канала")

    vw = sub.add_parser("view", help="Создать N просмотров (браузер на сервере)")
    vw.add_argument("channel_id", type=int, help="ID канала")
    vw.add_argument("count", type=int, help="Количество просмотров")
    vw.add_argument("--dwell", type=int, default=DEFAULT_DWELL, help=f"Секунд на странице (default: {DEFAULT_DWELL})")
    vw.add_argument("--account-id", dest="account_id", type=int, default=None, help="Использовать конкретный аккаунт (count=1)")

    from cli.job import parse_duration
    sch = sub.add_parser("schedule", help="Запланировать авто-просмотры")
    sch.add_argument("channel_id", type=int, help="ID канала")
    sch.add_argument("views_per_post", type=int, help="Просмотров на каждый пост")
    sch.add_argument("hours", type=parse_duration,
                     help="Длительность в формате Ч.ММ (48 = 48ч, 1.30 = 1ч 30мин, 0.20 = 20мин)")

    sub.add_parser("list-jobs", help="Список запланированных задач")
    cj = sub.add_parser("cancel-job", help="Отменить задачу")
    cj.add_argument("id", type=int, help="ID задачи")

    sub.add_parser("daemon-start", help="Возобновить планировщик на сервере")
    sub.add_parser("daemon-stop", help="Поставить планировщик на паузу")
    sub.add_parser("daemon-status", help="Статус планировщика на сервере")

    return parser


async def _async_dispatch(command: str, args) -> int:
    if command == "configure":
        from cli.configure import cmd_configure
        return await cmd_configure(args)
    if command == "add-account":
        from cli.account import cmd_add_account
        return await cmd_add_account(args)
    if command == "add-account-manual":
        from cli.account import cmd_add_account_manual
        return await cmd_add_account_manual(args)
    if command == "list-accounts":
        from cli.account import cmd_list_accounts
        return await cmd_list_accounts(args)
    if command == "remove-account":
        from cli.account import cmd_remove_account
        return await cmd_remove_account(args)
    if command == "add-channel":
        from cli.channel import cmd_add_channel
        return await cmd_add_channel(args)
    if command == "list-channels":
        from cli.channel import cmd_list_channels
        return await cmd_list_channels(args)
    if command == "remove-channel":
        from cli.channel import cmd_remove_channel
        return await cmd_remove_channel(args)
    if command == "refresh-memberships":
        from cli.channel import cmd_refresh_memberships
        return await cmd_refresh_memberships(args)
    if command == "view":
        from cli.view import cmd_view_browser
        return await cmd_view_browser(args)
    if command == "schedule":
        from cli.job import cmd_schedule
        return await cmd_schedule(args)
    if command == "list-jobs":
        from cli.job import cmd_list_jobs
        return await cmd_list_jobs(args)
    if command == "cancel-job":
        from cli.job import cmd_cancel_job
        return await cmd_cancel_job(args)
    if command == "daemon-start":
        from cli.job import cmd_daemon_start
        return await cmd_daemon_start(args)
    if command == "daemon-stop":
        from cli.job import cmd_daemon_stop
        return await cmd_daemon_stop(args)
    if command == "daemon-status":
        from cli.job import cmd_daemon_status
        return await cmd_daemon_status(args)
    return 2


def _ensure_configured() -> int:
    """0 — настроено; иначе печатает подсказку и возвращает 1."""
    from cli import config_store

    if config_store.is_configured():
        return 0
    print("❌ CLI ещё не настроен.", file=sys.stderr)
    print("   Выполните `max-viewer configure` (адрес сервера + API-ключ).", file=sys.stderr)
    return 1


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    # Без аргументов — интерактивная оболочка.
    if args.command is None:
        if _ensure_configured():
            return 1
        from cli.shell import run_shell
        return run_shell()

    # configure — не требует предварительной настройки.
    if args.command != "configure" and _ensure_configured():
        return 1

    return asyncio.run(_async_dispatch(args.command, args))


if __name__ == "__main__":
    sys.exit(main())
