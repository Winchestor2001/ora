"""CLI: разовые просмотры — `view <channel_id> <count>`.

Стримит живой прогресс с сервера (NDJSON) и печатает его, как раньше.
"""
from __future__ import annotations

import sys
from datetime import datetime

from cli import client
from cli.client import ApiError


async def cmd_view_browser(args) -> int:
    channel_id = args.channel_id
    count = args.count
    dwell = getattr(args, "dwell", 20)
    account_id = getattr(args, "account_id", None)

    if count <= 0:
        print("❌ Количество просмотров должно быть > 0.", file=sys.stderr)
        return 1

    body = {"count": count, "dwell": dwell}
    if account_id is not None:
        body["account_id"] = account_id

    started_at = datetime.now()
    success = failed = None
    errors: list = []

    try:
        async for ev in client.stream_ndjson(
            "POST", f"/channels/{channel_id}/view", json=body
        ):
            etype = ev.get("type")
            if etype == "error":
                print(f"❌ {ev.get('message')}", file=sys.stderr)
                return 1
            if etype == "start":
                names = ", ".join(ev.get("accounts", []))
                print()
                print(f"  Канал: {ev.get('channel_title')} (chat_id={ev.get('chat_id')})")
                print(f"  Запрошено просмотров: {ev.get('count')}")
                print(f"  Выбраны аккаунты: {names}")
                print(f"  Режим: браузер на сервере, dwell={ev.get('dwell')}с")
                print()
                print("  Запускаю…")
                print()
            elif etype == "progress":
                ts = datetime.now().strftime("%H:%M:%S")
                print(
                    f"  [{ts}] [#{ev.get('account_id')} "
                    f"{(ev.get('account_name') or ''):<14}] {ev.get('status')}",
                    flush=True,
                )
            elif etype == "done":
                success = ev.get("success", 0)
                failed = ev.get("failed", 0)
                errors = ev.get("errors", [])
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    if success is None:
        print("❌ Сервер не прислал итог (возможно, прервано).", file=sys.stderr)
        return 2

    elapsed = (datetime.now() - started_at).total_seconds()
    print()
    print("=" * 60)
    print(f"  Завершено за {int(elapsed)}с: {success}/{count} успешно")
    if failed:
        print(f"  Не удалось: {failed}")
        print()
        print("  Детали ошибок:")
        for r in errors:
            wait = r.get("waited_seconds") or 0
            wait_str = f" (ждал {wait}с)" if wait else ""
            print(f"    [#{r.get('account_id')} {r.get('account_name')}] {r.get('error')}{wait_str}")
    print("=" * 60)
    print()
    return 0 if not failed else 2
