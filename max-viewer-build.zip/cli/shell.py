"""Интерактивная оболочка (REPL) с tab-автодополнением и цветами."""
from __future__ import annotations

import asyncio
import cmd
import shlex
import sys
import traceback
from types import SimpleNamespace

from cli import colors as c


# Дефолтный dwell для `view`, если пользователь не указал явно. Реальное
# значение по умолчанию для планировщика задаётся на сервере (.env DWELL_SECONDS).
DEFAULT_DWELL = 20


# Tab-автодополнение: на macOS readline иногда заменяется libedit,
# у которого другой синтаксис привязки клавиш.
try:
    import readline  # noqa: F401
    if "libedit" in (readline.__doc__ or ""):
        readline.parse_and_bind("bind ^I rl_complete")
    else:
        readline.parse_and_bind("tab: complete")
except ImportError:
    pass


BANNER_RAW = r"""
╔══════════════════════════════════════════════════════╗
║   MAX Channel Viewer — интерактивная оболочка       ║
║                                                      ║
║   help                — список команд                ║
║   help <команда>      — справка по команде           ║
║   <Tab>               — автодополнение               ║
║   exit  /  Ctrl-D     — выход                        ║
╚══════════════════════════════════════════════════════╝
"""

BANNER = c.bcyan(BANNER_RAW)
PROMPT = c.bgreen("max") + c.gray(">") + " "


def _run(coro) -> int:
    """Выполняет async-команду и возвращает код возврата."""
    try:
        result = asyncio.run(coro)
        return result if isinstance(result, int) else 0
    except KeyboardInterrupt:
        print("\n" + c.yellow("(отменено)"))
        return 130
    except Exception as e:
        print(c.err(f"Ошибка: {e}"), file=sys.stderr)
        traceback.print_exc()
        return 1


class MaxShell(cmd.Cmd):
    intro = BANNER
    prompt = PROMPT

    # --- Команды управления аккаунтами ---

    def do_add_account(self, arg: str):
        """Добавить новый аккаунт MAX через QR-сканирование (автоматически)."""
        from cli.account import cmd_add_account
        _run(cmd_add_account(SimpleNamespace()))

    def do_add_account_manual(self, arg: str):
        """Добавить аккаунт вручную (paste значений из DevTools)."""
        from cli.account import cmd_add_account_manual
        _run(cmd_add_account_manual(SimpleNamespace()))

    def do_list_accounts(self, arg: str):
        """Показать список аккаунтов."""
        from cli.account import cmd_list_accounts
        _run(cmd_list_accounts(SimpleNamespace()))

    def do_remove_account(self, arg: str):
        """Удалить аккаунт.

        Использование: remove_account <id>
        """
        try:
            args = shlex.split(arg)
            if len(args) != 1:
                print("Использование: remove_account <id>")
                return
            account_id = int(args[0])
        except ValueError:
            print("ID должен быть числом.")
            return
        from cli.account import cmd_remove_account
        _run(cmd_remove_account(SimpleNamespace(id=account_id)))

    # --- Команды управления каналами ---

    def do_add_channel(self, arg: str):
        """Добавить канал.

        Использование: add_channel <url|chat_id|invite>
        Примеры:
          add_channel oneme_news
          add_channel https://max.ru/oneme_news
          add_channel -72667694999625
          add_channel https://max.ru/join/HP40PYYAHqi10aA0...
        """
        target = arg.strip()
        if not target:
            print("Использование: add_channel <url|chat_id|invite>")
            return
        from cli.channel import cmd_add_channel
        _run(cmd_add_channel(SimpleNamespace(target=target)))

    def do_list_channels(self, arg: str):
        """Список каналов."""
        from cli.channel import cmd_list_channels
        _run(cmd_list_channels(SimpleNamespace()))

    def do_remove_channel(self, arg: str):
        """Удалить канал.

        Использование: remove_channel <id>
        """
        try:
            args = shlex.split(arg)
            if len(args) != 1:
                print("Использование: remove_channel <id>")
                return
            channel_id = int(args[0])
        except ValueError:
            print("ID должен быть числом.")
            return
        from cli.channel import cmd_remove_channel
        _run(cmd_remove_channel(SimpleNamespace(id=channel_id)))

    def do_refresh_memberships(self, arg: str):
        """Перепроверить статус членства всех аккаунтов в канале.

        Использование: refresh_memberships <channel_id>
        Полезно после того, как admin одобрил приглашение —
        обновляет DB без траты просмотров.
        """
        try:
            args = shlex.split(arg)
            if len(args) != 1:
                print("Использование: refresh_memberships <channel_id>")
                return
            channel_id = int(args[0])
        except ValueError:
            print("ID должен быть числом.")
            return
        from cli.channel import cmd_refresh_memberships
        _run(cmd_refresh_memberships(SimpleNamespace(id=channel_id)))

    # --- Просмотры ---

    def do_view(self, arg: str):
        """Создать N просмотров через headless-браузер (надёжнее API).

        Использование:
          view <channel_id> <count> [dwell] [--headed] [--account-id N]

        Примеры:
          view 1 5                     # 5 случайных аккаунтов
          view 1 5 15                  # dwell 15с
          view 1 1 --account-id 2      # только аккаунт #2
          view 1 1 15 --headed --account-id 2
        """
        try:
            tokens = shlex.split(arg)
            headed = "--headed" in tokens
            tokens = [t for t in tokens if t != "--headed"]

            account_id = None
            if "--account-id" in tokens:
                idx = tokens.index("--account-id")
                if idx + 1 >= len(tokens):
                    print("--account-id требует значения")
                    return
                account_id = int(tokens[idx + 1])
                tokens = tokens[:idx] + tokens[idx + 2:]

            if len(tokens) < 2 or len(tokens) > 3:
                print("Использование: view <channel_id> <count> [dwell] [--headed] [--account-id N]")
                return
            channel_id = int(tokens[0])
            count = int(tokens[1])
            dwell = int(tokens[2]) if len(tokens) >= 3 else DEFAULT_DWELL
        except ValueError:
            print("channel_id, count, dwell, account-id должны быть числами.")
            return
        from cli.view import cmd_view_browser
        _run(cmd_view_browser(SimpleNamespace(
            channel_id=channel_id, count=count, dwell=dwell,
            headless=not headed, account_id=account_id,
        )))

    # --- Планировщик (auto-view) ---

    def do_schedule(self, arg: str):
        """Запланировать автоматические просмотры на длительность.

        Использование: schedule <channel_id> <views_per_post> <Ч.ММ>
        Примеры:       schedule 3 5 48      (на 48 часов)
                       schedule 3 5 1.30    (на 1 час 30 минут)
                       schedule 3 5 0.20    (на 20 минут)

        Длительность пишется как на часах: число после точки — это минуты
        (00–59), а не десятичная дробь. '0.2' читается как '0.20' = 20 минут.

        Демон автоматически:
          - распределяет просмотры во времени (рандомные паузы)
          - подхватывает новые посты по мере появления
          - использует разные аккаунты (один аккаунт = один просмотр на пост)

        Не забудьте запустить `run` после `schedule`.
        """
        from cli.job import cmd_schedule, parse_duration
        try:
            tokens = shlex.split(arg)
            if len(tokens) != 3:
                print("Использование: schedule <channel_id> <views_per_post> <Ч.ММ>")
                return
            channel_id = int(tokens[0])
            views_per_post = int(tokens[1])
            hours = parse_duration(tokens[2])
        except ValueError as e:
            print(f"Неверный аргумент: {e}" if str(e) else "Все аргументы должны быть числами.")
            return
        _run(cmd_schedule(SimpleNamespace(
            channel_id=channel_id, views_per_post=views_per_post, hours=hours,
        )))

    def do_list_jobs(self, arg: str):
        """Показать список запланированных задач."""
        from cli.job import cmd_list_jobs
        _run(cmd_list_jobs(SimpleNamespace()))

    def do_cancel_job(self, arg: str):
        """Отменить задачу.

        Использование: cancel_job <id>
        """
        try:
            tokens = shlex.split(arg)
            if len(tokens) != 1:
                print("Использование: cancel_job <id>")
                return
            job_id = int(tokens[0])
        except ValueError:
            print("ID должен быть числом.")
            return
        from cli.job import cmd_cancel_job
        _run(cmd_cancel_job(SimpleNamespace(id=job_id)))

    def do_daemon_start(self, arg: str):
        """Возобновить планировщик на сервере (если был на паузе)."""
        from cli.job import cmd_daemon_start
        _run(cmd_daemon_start(SimpleNamespace()))

    def do_daemon_stop(self, arg: str):
        """Поставить планировщик на сервере на паузу."""
        from cli.job import cmd_daemon_stop
        _run(cmd_daemon_stop(SimpleNamespace()))

    def do_daemon_status(self, arg: str):
        """Показать статус планировщика и число активных задач."""
        from cli.job import cmd_daemon_status
        _run(cmd_daemon_status(SimpleNamespace()))

    # --- Системные команды ---

    def do_configure(self, arg: str):
        """Настроить подключение к серверу (адрес + логин/пароль)."""
        from cli.configure import cmd_configure
        _run(cmd_configure(SimpleNamespace(url=None, user=None, password=None)))

    def do_help(self, arg: str):
        """Список команд или справка по конкретной команде."""
        if arg:
            super().do_help(arg)
            return
        # Группа: (заголовок, [(command, description)])
        groups = [
            ("Управление аккаунтами", [
                ("add_account",            "добавить аккаунт через QR (авто)"),
                ("add_account_manual",     "добавить аккаунт вручную"),
                ("list_accounts",          "список аккаунтов"),
                ("remove_account <id>",    "удалить аккаунт"),
            ]),
            ("Управление каналами", [
                ("add_channel <ссылка>",       "добавить канал (url/id/invite)"),
                ("list_channels",              "список каналов"),
                ("remove_channel <id>",        "удалить канал"),
                ("refresh_memberships <id>",   "обновить статус членства"),
            ]),
            ("Просмотры", [
                ("view <chan_id> <count>", "N просмотров (через headless-браузер)"),
            ]),
            ("Авто-режим (планировщик)", [
                ("schedule <chan> <views> <Ч.ММ>",  "запланировать (напр. 1.30 = 1ч 30мин)"),
                ("list_jobs",                        "список задач"),
                ("cancel_job <id>",                  "отменить задачу"),
                ("daemon_status",                    "статус планировщика на сервере"),
                ("daemon_stop",                      "поставить планировщик на паузу"),
                ("daemon_start",                     "возобновить планировщик"),
            ]),
            ("Система", [
                ("configure",         "настроить сервер (адрес + API-ключ)"),
                ("help [<команда>]",  "справка"),
                ("clear",             "очистить экран"),
                ("exit / quit",       "выход"),
            ]),
        ]
        print()
        for title, items in groups:
            print(c.header(title) + ":")
            for cmd_str, desc in items:
                print(f"  {c.bgreen(cmd_str.ljust(36))} {c.gray('—')} {desc}")
            print()

    def do_clear(self, arg: str):
        """Очистить экран."""
        print("\033[2J\033[H", end="")

    def do_exit(self, arg: str):
        """Выйти из оболочки."""
        print(c.cyan("👋 До свидания."))
        return True

    do_quit = do_exit
    do_EOF = do_exit  # Ctrl+D

    # --- UX ---

    def emptyline(self):
        pass

    def default(self, line: str):
        print(c.warn(f"Неизвестная команда: {line!r}. Введите ") + c.bgreen("help") + ".")


def run_shell() -> int:
    try:
        MaxShell().cmdloop()
        return 0
    except KeyboardInterrupt:
        print("\n" + c.cyan("👋 До свидания."))
        return 0
