"""ANSI цветовые коды и хелперы для консоли."""
import os
import sys


# На Windows консоль по умолчанию не обрабатывает ANSI-коды — colorama включает
# их (Win10+). На macOS/Linux и при отсутствии colorama — безвредный no-op.
try:
    import colorama
    colorama.just_fix_windows_console()
except Exception:
    pass


# Поддержка цвета: TTY + не отключено через NO_COLOR
ENABLED = sys.stdout.isatty() and "NO_COLOR" not in os.environ


def _wrap(code: str):
    def fn(text: str) -> str:
        if not ENABLED:
            return text
        return f"\033[{code}m{text}\033[0m"
    return fn


# Стили
bold = _wrap("1")
dim = _wrap("2")
underline = _wrap("4")

# Базовые цвета
red = _wrap("31")
green = _wrap("32")
yellow = _wrap("33")
blue = _wrap("34")
magenta = _wrap("35")
cyan = _wrap("36")
white = _wrap("37")
gray = _wrap("90")

# Жирные
bred = _wrap("1;31")
bgreen = _wrap("1;32")
byellow = _wrap("1;33")
bblue = _wrap("1;34")
bcyan = _wrap("1;36")


def ok(text: str) -> str:
    return green(f"✓ {text}")


def err(text: str) -> str:
    return red(f"✗ {text}")


def warn(text: str) -> str:
    return yellow(f"⚠ {text}")


def info(text: str) -> str:
    return cyan(f"ℹ {text}")


def header(text: str) -> str:
    return bold(cyan(text))
