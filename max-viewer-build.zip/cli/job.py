"""CLI: планировщик-задачи и управление планировщиком — через HTTP API.

Прежний демон-подпроцесс заменён планировщиком внутри сервера. Команды
daemon_start/stop/status теперь означают возобновление/паузу/статус.
"""
from __future__ import annotations

import sys

from cli import client
from cli.client import ApiError


def _fmt_ts(iso: str | None) -> str:
    if not iso:
        return "—"
    return iso[:16].replace("T", " ")


def parse_duration(text: str) -> float:
    """Разобрать длительность из формата Ч.ММ в часы (float).

    Минуты пишутся как на часах (00–59), а не как десятичная дробь:
        '48'    -> 48.0           (48 часов)
        '1.30'  -> 1.5            (1 час 30 минут)
        '0.2'   -> 0.333…         (20 минут; '.2' читается как '.20')
        '0.05'  -> 0.0833…        (5 минут)
        '.45'   -> 0.75           (45 минут)
    """
    text = text.strip()
    if "." not in text:
        hours, minutes = int(text), 0
    else:
        h_str, m_str = text.split(".", 1)
        hours = int(h_str) if h_str else 0
        if m_str == "":
            minutes = 0
        else:
            if len(m_str) > 2 or not m_str.isdigit():
                raise ValueError("минуты пишутся как на часах: например 0.20 или 1.30")
            # '.2' == '.20' (как в записи времени), '.05' == 5 минут
            minutes = int(m_str.ljust(2, "0"))
    if minutes > 59:
        raise ValueError("минуты должны быть в диапазоне 00–59")
    total = hours + minutes / 60
    if total <= 0:
        raise ValueError("длительность должна быть больше нуля")
    return total


def format_duration(hours: float) -> str:
    """Человекочитаемая длительность: 1.5 -> '1 ч 30 мин'."""
    total_min = round(hours * 60)
    h, m = divmod(total_min, 60)
    if h and m:
        return f"{h} ч {m} мин"
    if h:
        return f"{h} ч"
    return f"{m} мин"


async def cmd_schedule(args) -> int:
    body = {
        "channel_id": args.channel_id,
        "views_per_post": args.views_per_post,
        "hours": args.hours,
    }
    try:
        job = await client.request("POST", "/jobs", json=body)
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    print(f"✓ Задача #{job['id']} создана:")
    print(f"    Канал:          {job['channel_title']}")
    print(f"    Просм. на пост: {job['views_per_post']}")
    print(f"    Длительность:   {format_duration(job['hours'])}")
    print(f"    Заканчивается:  {_fmt_ts(job['ends_at'])}")
    print()
    print("ℹ️  Планировщик работает на сервере постоянно — задача подхватится автоматически.")
    return 0


async def cmd_list_jobs(args) -> int:
    try:
        jobs = await client.request("GET", "/jobs")
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    if not jobs:
        print("Задач нет. Создайте через `schedule <channel_id> <views_per_post> <hours>`.")
        return 0

    print(
        f"{'ID':<5} {'Канал':<30} {'Просм/пост':<11} "
        f"{'Заканчивается':<20} {'Статус':<12}"
    )
    print("-" * 84)
    for j in jobs:
        emoji = {
            "active": "🟢",
            "paused": "⏸",
            "completed": "✓",
            "cancelled": "⌀",
            "failed": "❌",
        }.get(j["status"], "❔")
        title = (j["channel_title"] or "—")[:28]
        ends = _fmt_ts(j["ends_at"])
        print(
            f"{j['id']:<5} {title:<30} {j['views_per_post']:<11} "
            f"{ends:<20} {emoji} {j['status']:<10}"
        )
    return 0


async def cmd_cancel_job(args) -> int:
    job_id = args.id
    try:
        await client.request("DELETE", f"/jobs/{job_id}")
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1
    print(f"✓ Задача #{job_id} отменена.")
    return 0


async def cmd_daemon_start(args) -> int:
    """Возобновить планировщик на сервере."""
    try:
        await client.request("POST", "/scheduler/resume")
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1
    print("✓ Планировщик возобновлён.")
    return 0


async def cmd_daemon_stop(args) -> int:
    """Поставить планировщик на паузу (сервер продолжает работать)."""
    try:
        await client.request("POST", "/scheduler/pause")
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1
    print("✓ Планировщик поставлен на паузу.")
    return 0


async def cmd_daemon_status(args) -> int:
    try:
        st = await client.request("GET", "/scheduler/status")
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1
    running = st.get("running")
    paused = st.get("paused")
    active = st.get("active_jobs", 0)
    if running and not paused:
        print(f"🟢 планировщик работает, активных задач: {active}")
    elif running and paused:
        print(f"⏸ планировщик на паузе, активных задач: {active}")
    else:
        print(f"⚪ планировщик не запущен, активных задач: {active}")
    return 0
