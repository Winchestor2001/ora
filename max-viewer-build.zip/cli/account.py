"""CLI: управление аккаунтами — теперь через HTTP API сервера."""
from __future__ import annotations

import json
import re
import sys

from cli import client
from cli.client import ApiError


UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


MANUAL_INSTRUCTIONS = """
Чтобы добавить новый аккаунт MAX вручную:

  1. Откройте в браузере https://web.max.ru
  2. На телефоне откройте MAX → Настройки →
     «Другие устройства» → «Сканировать QR-код»
  3. После входа: F12 → Application → Local Storage → web.max.ru
  4. Скопируйте значения __oneme_auth и __oneme_device_id

(или Ctrl+C — отмена)
"""


def _print_saved(account: dict) -> None:
    print()
    print("✓ Аккаунт успешно добавлен:")
    print(f"    Аккаунт #{account['id']}")
    print(f"    Имя:      {account.get('name') or '—'}")
    print(f"    User ID:  {account.get('user_id')}")
    print(f"    Телефон:  {account.get('phone') or '—'}")
    print(f"    Статус:   активен")


async def cmd_add_account(args) -> int:
    """Автоматический режим: QR-код приходит с сервера, скан телефоном."""
    from cli.qr_login import add_account_via_qr
    return await add_account_via_qr()


async def cmd_add_account_manual(args) -> int:
    """Ручной режим — paste значений из DevTools (парсинг локально)."""
    print(MANUAL_INSTRUCTIONS)

    print("Вставьте значение __oneme_auth (одной строкой):")
    raw = input("> ").strip()
    try:
        data = json.loads(raw)
        token = data["token"]
        user_id = int(data["viewerId"])
    except (json.JSONDecodeError, KeyError, ValueError) as e:
        print(f"❌ Ошибка формата: {e}", file=sys.stderr)
        print("   Ожидается: {\"token\":\"...\",\"viewerId\":...}", file=sys.stderr)
        return 1

    print(f"✓ Токен принят (user_id={user_id})\n")

    print("Вставьте значение __oneme_device_id (формат UUID):")
    device_id = input("> ").strip().lower()
    if not UUID_RE.match(device_id):
        print(f"❌ Не похоже на UUID: {device_id!r}", file=sys.stderr)
        print("   Пример: 73b7eb0f-227d-4732-8580-788292bb41c0", file=sys.stderr)
        return 1

    print("\n→ Отправляю на сервер для проверки…")
    try:
        account = await client.request(
            "POST", "/accounts/manual",
            json={"token": token, "user_id": user_id, "device_id": device_id},
        )
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1
    _print_saved(account)
    return 0


async def cmd_list_accounts(args) -> int:
    try:
        accounts = await client.request("GET", "/accounts")
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    if not accounts:
        print("Аккаунтов нет. Добавьте через `add_account`.")
        return 0

    print(f"{'ID':<5} {'Имя':<20} {'User ID':<15} {'Телефон':<16} {'Статус':<12} {'Запусков':<10}")
    print("-" * 84)
    for a in accounts:
        emoji = {"active": "🟢", "paused": "⏸", "banned": "🔴"}.get(a["status"], "❔")
        status_ru = {
            "active": "активен",
            "paused": "пауза",
            "banned": "забанен",
        }.get(a["status"], a["status"])
        name = (a["name"] or "—")[:18]
        phone = a["phone"] or "—"
        print(
            f"{a['id']:<5} {name:<20} {a['user_id']:<15} {phone:<16} "
            f"{emoji} {status_ru:<10} {a['views_total']:<10}"
        )
    print()
    print("  ‹Запусков› — сколько раз браузер успешно отработал для аккаунта.")
    print("  Это не равно реальному счётчику просмотров на сервере MAX —")
    print("  часть просмотров может быть отфильтрована анти-ботом.")
    return 0


async def cmd_remove_account(args) -> int:
    account_id = args.id
    try:
        await client.request("DELETE", f"/accounts/{account_id}")
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1
    print(f"✓ Аккаунт #{account_id} удалён.")
    return 0
