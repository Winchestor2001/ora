"""Локальная конфигурация CLI: адрес сервера + логин/пароль.

Хранится в ~/.config/max-viewer/config.json (chmod 600). Можно переопределить
переменными окружения MAX_VIEWER_SERVER_URL / MAX_VIEWER_USER / MAX_VIEWER_PASSWORD.
"""
from __future__ import annotations

import json
import os
from pathlib import Path


CONFIG_DIR = Path.home() / ".config" / "max-viewer"
CONFIG_PATH = CONFIG_DIR / "config.json"


class NotConfigured(Exception):
    """CLI ещё не настроен (нет server URL / логина / пароля)."""


def load() -> dict:
    """Возвращает {'server_url', 'username', 'password'} или бросает NotConfigured."""
    url = os.environ.get("MAX_VIEWER_SERVER_URL")
    user = os.environ.get("MAX_VIEWER_USER")
    pw = os.environ.get("MAX_VIEWER_PASSWORD")
    if url and user and pw:
        return {"server_url": url.rstrip("/"), "username": user, "password": pw}

    if CONFIG_PATH.exists():
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            data = {}
        if data.get("server_url") and data.get("username") and data.get("password"):
            return {
                "server_url": str(data["server_url"]).rstrip("/"),
                "username": str(data["username"]),
                "password": str(data["password"]),
            }

    raise NotConfigured(
        "CLI ещё не настроен. Выполните `configure` "
        "(укажите адрес сервера, логин и пароль)."
    )


def is_configured() -> bool:
    try:
        load()
        return True
    except NotConfigured:
        return False


def save(server_url: str, username: str, password: str) -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        json.dumps(
            {
                "server_url": server_url.rstrip("/"),
                "username": username,
                "password": password,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    try:
        CONFIG_PATH.chmod(0o600)
    except OSError:
        pass
    return CONFIG_PATH
