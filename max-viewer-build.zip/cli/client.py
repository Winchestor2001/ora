"""HTTP-клиент CLI к серверу MAX Channel Viewer.

Тонкая обёртка над httpx: подставляет base_url + Basic-аутентификацию, превращает
ошибки сервера/сети в понятные сообщения (ApiError), умеет читать NDJSON-поток
(живой прогресс просмотров).
"""
from __future__ import annotations

import json as _json
from typing import Any, AsyncIterator

import httpx

from cli import config_store


class ApiError(Exception):
    """Любая ошибка обращения к серверу (сеть/HTTP/валидация)."""


def _make_client(timeout) -> httpx.AsyncClient:
    cfg = config_store.load()
    return httpx.AsyncClient(
        base_url=cfg["server_url"],
        auth=httpx.BasicAuth(cfg["username"], cfg["password"]),
        timeout=timeout,
    )


def _detail(resp: httpx.Response) -> str:
    if resp.status_code == 401:
        return "Неверный логин или пароль. Перенастройте через `configure`."
    try:
        data = resp.json()
    except Exception:
        return (resp.text or "").strip() or f"HTTP {resp.status_code}"

    detail = data.get("detail") if isinstance(data, dict) else None
    if isinstance(detail, list):  # 422 — ошибки валидации
        parts = []
        for d in detail:
            loc = ".".join(str(x) for x in d.get("loc", []) if x != "body")
            parts.append(f"{loc}: {d.get('msg')}" if loc else str(d.get("msg")))
        return "; ".join(parts) or "ошибка валидации"
    return detail or f"HTTP {resp.status_code}"


def _conn_error() -> ApiError:
    try:
        url = config_store.load()["server_url"]
    except config_store.NotConfigured:
        url = "?"
    return ApiError(f"не удалось подключиться к серверу: {url}")


async def request(
    method: str,
    path: str,
    *,
    json: Any = None,
    params: dict | None = None,
    timeout: float = 60.0,
) -> Any:
    try:
        async with _make_client(timeout) as client:
            resp = await client.request(method, path, json=json, params=params)
    except httpx.ConnectError:
        raise _conn_error()
    except httpx.HTTPError as e:
        raise ApiError(f"сетевая ошибка: {e}")

    if resp.status_code >= 400:
        raise ApiError(_detail(resp))
    if resp.content:
        return resp.json()
    return None


async def stream_ndjson(
    method: str, path: str, *, json: Any = None
) -> AsyncIterator[dict]:
    """Стримит ответ построчно (NDJSON) — для живого прогресса просмотров."""
    timeout = httpx.Timeout(30.0, read=None)  # read=None: ждём долго работающий браузер
    try:
        async with _make_client(timeout) as client:
            async with client.stream(method, path, json=json) as resp:
                if resp.status_code >= 400:
                    await resp.aread()
                    raise ApiError(_detail(resp))
                async for line in resp.aiter_lines():
                    line = line.strip()
                    if line:
                        yield _json.loads(line)
    except httpx.ConnectError:
        raise _conn_error()
    except httpx.HTTPError as e:
        raise ApiError(f"сетевая ошибка: {e}")
