"""Команда `configure` — настройка адреса сервера, логина и пароля."""
from __future__ import annotations

import getpass
import sys

import httpx

from cli import colors as c
from cli import config_store
from cli.server_defaults import DEFAULT_SERVER_URL


async def _check(server_url: str, username: str, password: str) -> str | None:
    """Проверяет связь и учётные данные. Возвращает текст ошибки или None."""
    base = server_url.rstrip("/")
    auth = httpx.BasicAuth(username, password)
    try:
        async with httpx.AsyncClient(base_url=base, timeout=15.0) as cl:
            health = await cl.get("/health")
            if health.status_code != 200:
                return f"/health вернул HTTP {health.status_code}"
            # Проверяем логин/пароль на защищённом эндпоинте.
            sched = await cl.get("/scheduler/status", auth=auth)
            if sched.status_code == 401:
                return "сервер доступен, но логин или пароль неверны"
            if sched.status_code != 200:
                return f"/scheduler/status вернул HTTP {sched.status_code}"
    except httpx.HTTPError as e:
        return f"не удалось подключиться: {e}"
    return None


async def cmd_configure(args) -> int:
    server_url = getattr(args, "url", None)
    username = getattr(args, "user", None)
    password = getattr(args, "password", None)

    print(c.header("Настройка CLI") + " — подключение к серверу MAX Channel Viewer")
    print()

    if not server_url:
        # Enter — берём адрес по умолчанию (вшит в .exe), вводить ничего не нужно.
        server_url = input(f"Адрес сервера [{DEFAULT_SERVER_URL}]: ").strip() or DEFAULT_SERVER_URL
    if not username:
        username = input("Логин: ").strip()
    if not password:
        password = getpass.getpass("Пароль: ").strip()

    if not username or not password:
        print(c.err("Логин и пароль не должны быть пустыми."), file=sys.stderr)
        return 1

    # Сервер работает по HTTP (прямой доступ по IP), поэтому без схемы — http://.
    if not server_url.startswith(("http://", "https://")):
        server_url = "http://" + server_url

    print()
    print(f"  → Проверяю {server_url}…")
    err = await _check(server_url, username, password)
    if err:
        print(c.err(f"Проверка не пройдена: {err}"), file=sys.stderr)
        print("   Настройки не сохранены. Проверьте данные и повторите.", file=sys.stderr)
        return 1

    path = config_store.save(server_url, username, password)
    print(c.ok(f"Готово. Настройки сохранены: {path}"))
    print("  Теперь доступны все команды (list_accounts, view, schedule …).")
    return 0
