"""CLI: управление каналами — через HTTP API сервера."""
from __future__ import annotations

import sys

from cli import client
from cli.client import ApiError


async def cmd_add_channel(args) -> int:
    raw = args.target.strip()
    if not raw:
        print("Использование: add_channel <url|chat_id|invite>", file=sys.stderr)
        return 1

    print(f"→ Резолвлю канал на сервере…")
    try:
        ch = await client.request("POST", "/channels", json={"target": raw}, timeout=120.0)
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    print()
    print("✓ Канал добавлен:")
    print(f"    Канал #{ch['id']}")
    print(f"    Название: {ch['title']}")
    print(f"    chat_id:  {ch['chat_id']}")
    print(f"    Тип:      {ch['kind']}")
    return 0


async def cmd_list_channels(args) -> int:
    try:
        channels = await client.request("GET", "/channels")
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    if not channels:
        print("Каналов нет. Добавьте через `add_channel <url>`.")
        return 0

    print(
        f"{'ID':<5} {'Название':<32} {'chat_id':<18} {'Тип':<8} "
        f"{'Активны':<10} {'Ожидают':<10}"
    )
    print("-" * 86)
    for c in channels:
        title = (c["title"] or "—")[:30]
        print(
            f"{c['id']:<5} {title:<32} {c['chat_id']:<18} {c['kind']:<8} "
            f"{c['active']:<10} {c['pending']:<10}"
        )
    print()
    print("  ‹Тип› — тип канала (public/invite), не меняется")
    print("  ‹Активны› — ваши аккаунты, состоящие в канале")
    print("  ‹Ожидают› — аккаунты, ждущие подтверждения admin'а")
    return 0


async def cmd_remove_channel(args) -> int:
    channel_id = args.id
    try:
        await client.request("DELETE", f"/channels/{channel_id}")
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1
    print(f"✓ Канал #{channel_id} удалён.")
    return 0


async def cmd_refresh_memberships(args) -> int:
    channel_id = args.id
    print(f"  Проверяю членство аккаунтов в канале #{channel_id} на сервере…")
    print()
    try:
        res = await client.request(
            "POST", f"/channels/{channel_id}/refresh-memberships", timeout=300.0
        )
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    print(f"  Канал: {res['channel_title']}")
    print()
    label = {
        "active": "🟢 active",
        "pending": "⏳ pending",
        "not_member": "⚪ не состоит в канале",
        "error": "❌",
    }
    for row in res["accounts"]:
        line = f"  [#{row['account_id']} {row['name']}] {label.get(row['status'], row['status'])}"
        if row.get("detail"):
            line += f" {row['detail']}"
        print(line)

    print()
    print(
        f"  Итог: 🟢 {res['active']} активных, ⏳ {res['pending']} ожидают, "
        f"❌ {res['errors']} ошибок."
    )
    return 0
