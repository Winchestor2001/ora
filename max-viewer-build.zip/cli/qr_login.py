"""QR-логин через сервер: сервер отдаёт картинку с QR, мы показываем её,
телефон сканирует, сервер сам ловит вход и сохраняет аккаунт.

Локальный браузер больше не запускается.
"""
from __future__ import annotations

import asyncio
import base64
import subprocess
import sys
import tempfile
from pathlib import Path

from cli import client
from cli.client import ApiError


POLL_INTERVAL = 2.0


def _open_image(path: Path) -> None:
    """Открывает картинку в системном просмотрщике (best-effort)."""
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        elif sys.platform.startswith("win"):
            import os
            os.startfile(str(path))  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", str(path)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass  # не критично — путь к файлу всё равно напечатан


async def add_account_via_qr() -> int:
    print()
    print("→ Запрашиваю QR-код у сервера…")
    try:
        start = await client.request("POST", "/accounts/qr/start", timeout=90.0)
    except ApiError as e:
        print(f"❌ {e}", file=sys.stderr)
        return 1

    session_id = start["session_id"]
    timeout_seconds = start.get("timeout_seconds", 300)

    png_b64 = start.get("qr_png_base64")
    if not png_b64:
        print("❌ Сервер не вернул изображение QR.", file=sys.stderr)
        return 1

    qr_path = Path(tempfile.gettempdir()) / f"max-qr-{session_id}.png"
    qr_path.write_bytes(base64.b64decode(png_b64))
    _open_image(qr_path)

    print()
    print(f"  📱 Открыт QR-код: {qr_path}")
    print("     Отсканируйте его приложением MAX на телефоне:")
    print("     MAX → Настройки → «Другие устройства» → «Сканировать QR-код»")
    print(f"  ⏱  Ожидание (до {timeout_seconds // 60} мин)… (Ctrl+C — отмена)")
    print()

    elapsed = 0.0
    last_log = 0.0
    try:
        while elapsed < timeout_seconds + 10:
            try:
                sess = await client.request("GET", f"/accounts/qr/{session_id}")
            except ApiError as e:
                print(f"❌ {e}", file=sys.stderr)
                return 1

            status = sess.get("status")
            if status == "done":
                account = sess.get("account") or {}
                print("  ✓ QR-код принят, аккаунт добавлен.")
                print()
                print(f"    Аккаунт #{account.get('id')}")
                print(f"    Имя:      {account.get('name') or '—'}")
                print(f"    User ID:  {account.get('user_id')}")
                print(f"    Телефон:  {account.get('phone') or '—'}")
                _cleanup(qr_path)
                return 0
            if status in ("error", "expired"):
                print(f"❌ {sess.get('error') or status}", file=sys.stderr)
                _cleanup(qr_path)
                return 1

            if elapsed - last_log >= 30:
                remaining = int(timeout_seconds - elapsed)
                print(f"     …осталось ~{max(0, remaining) // 60}m {max(0, remaining) % 60}s")
                last_log = elapsed

            await asyncio.sleep(POLL_INTERVAL)
            elapsed += POLL_INTERVAL
    except KeyboardInterrupt:
        print("\n  (отменено)")
        _cleanup(qr_path)
        return 130

    print("❌ Истёк таймаут — QR не отсканирован.", file=sys.stderr)
    _cleanup(qr_path)
    return 1


def _cleanup(path: Path) -> None:
    try:
        path.unlink()
    except OSError:
        pass
